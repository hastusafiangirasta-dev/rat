package com.example.parentalcontrol

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.DataOutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val uuid: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
    private var socket: BluetoothSocket? = null
    private lateinit var status: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) sendWallpaper(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        findViewById<Button>(R.id.connectBtn).setOnClickListener { requestBtThenConnect() }
        findViewById<Button>(R.id.startBtn).setOnClickListener { sendCommand("LOCK") }
        findViewById<Button>(R.id.stopBtn).setOnClickListener { sendCommand("STOP") }
        findViewById<Button>(R.id.wallpaperBtn).setOnClickListener { picker.launch("image/*") }
    }

    private fun requestBtThenConnect() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 101)
        } else connect()
    }

    private fun connect() {
        val mac = findViewById<EditText>(R.id.macInput).text.toString().trim()
        if (mac.isBlank()) { status.text = "Masukkan alamat Bluetooth perangkat anak."; return }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { status.text = "Aktifkan Bluetooth terlebih dahulu."; return }
        thread {
            try {
                val device = adapter.getRemoteDevice(mac)
                val s = device.createRfcommSocketToServiceRecord(uuid)
                adapter.cancelDiscovery()
                s.connect()
                socket = s
                runOnUiThread { status.text = "Status: terhubung ke perangkat anak." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal terhubung: ${e.localizedMessage ?: "periksa pairing dan alamat MAC"}" }
            }
        }
    }

    private fun sendCommand(command: String) {
        thread {
            try {
                val s = socket ?: throw IllegalStateException("Belum terhubung.")
                synchronized(s) { DataOutputStream(s.outputStream).apply { writeUTF(command); flush() } }
                runOnUiThread { status.text = "Perintah terkirim: $command" }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.localizedMessage ?: "Gagal mengirim perintah." }
            }
        }
    }

    private fun sendWallpaper(uri: Uri) {
        thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Gambar tidak dapat dibaca.")
                require(bytes.size <= 8 * 1024 * 1024) { "Ukuran gambar maksimal 8 MB." }
                val s = socket ?: error("Belum terhubung.")
                synchronized(s) {
                    val out = DataOutputStream(s.outputStream)
                    out.writeUTF("WALLPAPER")
                    out.writeInt(bytes.size)
                    out.write(bytes)
                    out.flush()
                }
                runOnUiThread { status.text = "Wallpaper berhasil dikirim." }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.localizedMessage ?: "Gagal mengirim wallpaper." }
            }
        }
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
