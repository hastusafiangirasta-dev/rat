# Parental Control

Proyek Android Kotlin starter dengan workflow GitHub Actions.

## Build APK di GitHub
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke root repository.
3. Buka tab **Actions**, jalankan workflow **Build Android APK**.
4. Unduh APK dari bagian **Artifacts** pada hasil workflow.

## Persyaratan
- JDK 17, Gradle 8.9, Android SDK Platform 35.
- Kedua HP harus mengaktifkan Bluetooth dan dipasangkan melalui Settings Android.

## Catatan penggunaan
- Aplikasi Kid harus terbuka dan menekan tombol menunggu koneksi.
- Izin Bluetooth dan Device Admin harus disetujui secara manual di perangkat anak.
- Bluetooth server starter ini berjalan saat aplikasi Kid terbuka, bukan sebagai layanan latar belakang permanen.
- STOP menghentikan kontrol; Android tidak mengizinkan aplikasi membuka kunci layar yang sudah terkunci secara diam-diam.
